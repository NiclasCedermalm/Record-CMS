package org.record.content.model.data

class TextContentData extends ConcreteContentData {
	var text: String = _
	
	/*
	override def serialize = {
	  super.serialize
	}
	
	override def deserialize = {
	  super.deserialize
	}
	*/
}