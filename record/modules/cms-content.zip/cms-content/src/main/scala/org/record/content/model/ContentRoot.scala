package org.record.content.model
import org.record.content.model.data.ContentRootData

class ContentRoot(override val contentData : ContentRootData) extends HierarchicalContent(contentData) {
	
}