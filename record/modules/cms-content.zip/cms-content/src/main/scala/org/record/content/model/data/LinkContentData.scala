package org.record.content.model.data

class LinkContentData extends ConcreteContentData {
  var title: String = _
  var linkTo: ContentData = _
}