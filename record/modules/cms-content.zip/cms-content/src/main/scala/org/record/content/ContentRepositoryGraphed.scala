package org.record.content

import com.orientechnologies.orient.core.sql.query.OSQLSynchQuery
import com.orientechnologies.orient.core.record.impl.ODocument
import org.record.content.model.Taxonomy
import org.record.content.model.Content
import com.orientechnologies.orient.core.db.`object`.ODatabaseObjectTx
import com.orientechnologies.orient.core.storage.OStorage
import com.orientechnologies.orient.core.serialization.serializer.`object`.OObjectSerializerHelper
import com.orientechnologies.orient.core.db.document.ODatabaseDocumentTx
import com.orientechnologies.orient.core.db.graph.OGraphDatabase
import org.record.content.model.Page
import com.orientechnologies.orient.core.sql.query.OSQLSynchQuery
import scala.collection.JavaConverters._
import scala.collection.JavaConversions._
import com.orientechnologies.orient.core.exception.OQueryParsingException


class ContentRepositoryGraphed(val zoneName : String, val db : OGraphDatabase) {
 
  // Some implicit magic comes here...
  implicit def dbWrapper(db: OGraphDatabase) = new {
	 def queryBySql[T](sql: String, params: AnyRef*): List[T] = {
        val params4java = params.toArray
        try {
        	val results : java.util.List[T] = db.query(new OSQLSynchQuery[T](sql), params4java: _*)
        	return results.asScala.toList
        }
        catch {
          case e : OQueryParsingException => return List[T]()
        }
       
     }
  }
  
  protected def createNode(nodeItem : NodeItem) {
    nodeItem.node = db.newInstance(nodeItem.getClass.getSimpleName())
    
  }
  
   def save(nodeItem : NodeItem) = {
    if ( nodeItem.node == null ) {
      createNode(nodeItem)
    }
    nodeItem.serialize
    nodeItem.node = db.save(nodeItem.node).asInstanceOf[ODocument]
  } 
  
  // TODO: Use generics here!!
  def load(id : String) : NodeItem = {
    null
  }
  
  def getContent(id : String) : Content  = {
    
    // TODO: How to fetch by ID??
	return null
  }
  
  
  def getPage(path : String, filename : String) : Page = {
    val result = db.queryBySql[Page]("Select from Page where path=? and filename=?", path, filename)
    return result.head
  }
  
  def queryContent(taxonomies : List[Taxonomy]) : List[Content] = {
    return null;
  }
  
  def getContentRoot() : Content = {
    
    // Return ref to hierarchical content??
    return null
  }
  
  def publish(content : Content, zoneName : String) = {
    
  }
 
 
  
}

 