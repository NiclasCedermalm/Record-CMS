package org.record.content

import scala.collection.JavaConverters._
import scala.collection.JavaConversions._
import com.orientechnologies.orient.core.sql.query.OSQLSynchQuery
import com.orientechnologies.orient.core.record.impl.ODocument
import org.record.content.model.Taxonomy
import org.record.content.model.Content
import com.orientechnologies.orient.core.db.`object`.ODatabaseObjectTx
import com.orientechnologies.orient.core.storage.OStorage
import com.orientechnologies.orient.core.serialization.serializer.`object`.OObjectSerializerHelper
import com.orientechnologies.orient.core.db.document.ODatabaseDocumentTx
import org.record.content.model.ContentRoot
import com.orientechnologies.orient.core.exception.OQueryParsingException
import org.record.content.model.data._


class ContentRepository(val db : ODatabaseObjectTx) {
 
  // TODO: Read Orient DB setups from config file??
  
  // Implicit magic...
  implicit def dbWrapper(db: ODatabaseObjectTx) = new {
    def queryBySql[T](sql: String, params: AnyRef*): List[T] = {
      val params4java = params.toArray
      try {
	      val results: java.util.List[T] = db.query(new OSQLSynchQuery[T](sql), params4java: _*)
	      return results.asScala.toList
      }
      catch {
          case e : OQueryParsingException => return List[T]()
      }
    }
  }
  
  db.getEntityManager.registerEntityClasses("org.record.content.model.data")
  println("Classes registered...")
  
  /*
  if ( db.getClusterIdByName(zoneName) == -1 )
  {
	  db.addCluster(zoneName, OStorage.CLUSTER_TYPE.PHYSICAL)
  }
 */
  
  def save(content : ContentData) {
    db.save(content) 
  }
  
  def getContent(id : String) : Content = {
    
    db.query(new OSQLSynchQuery[ODocument]("select from ..."));
    // select from 11:4 where any() traverse(0,10) (@class = 'Profile' && address.city = 'Rome')
    // TODO: How to query??
    return null;
  }
  
  def query[T](query : String, params: AnyRef*) : List[T] = {
    db.queryBySql[T](query, params)
  }
  
  def queryContent(taxonomies : List[Taxonomy]) : List[Content] = {
    return null;
  }
  
  def getContentRoot(name : String) : ContentRoot = {
    if ( db.countClass("ContentRootData") == 0 ) return null
	var list = db.queryBySql[ContentRootData]("select from ContentRootData where name = ?", name)
	if ( list.isEmpty ) return null
    return Content.retrieveRuntimeContent[ContentRoot](list.head.asInstanceOf[ContentRootData]);
  }
  
  def publish(content : Content, zoneName : String) = {
    
  }
 
  
}