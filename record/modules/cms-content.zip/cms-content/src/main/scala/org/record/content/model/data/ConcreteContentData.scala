package org.record.content.model.data

abstract class ConcreteContentData extends ContentData {

}