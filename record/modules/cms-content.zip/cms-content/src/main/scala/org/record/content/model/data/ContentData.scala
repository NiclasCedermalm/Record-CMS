package org.record.content.model.data

import scala.collection.JavaConverters._
import scala.collection.JavaConversions._
import java.util.ArrayList
import javax.persistence.Id
import org.record.content.model.Content
import org.record.content.util.DynamicTraitFactory
import org.record.content.NodeItem

abstract class ContentData /*extends NodeItem*/ {

  @Id
  var id : String = _
  
  var test: String = _
  
  var parent : HierarchicalContentData = _ // TODO: This is not written to DB. WHY???
  
  var behaviours : ArrayList[BehaviourData] = new ArrayList[BehaviourData]
  
  // TODO: Will it be possible to save this content having this method??

  // This is used to get runtime version of a specific data for example when mapping a data list
 
  /*
  def retrieveRuntimeContent[T <: Content] : T = {
    println("Getting runtime content for id: " + id)
    val traitClassNames = 
      behaviours.asScala.toList.map(behaviour => { 
      if ( behaviour == null ) ""
      behaviour.traitClassName 
      } )

    return DynamicTraitFactory.newInstance(retrieveRuntimeContentClass, Array(this), traitClassNames).asInstanceOf[T]
  }
  
  def retrieveRuntimeContentClass : Class[_ <: Content] = {
    val dataClassName = this.getClass.getCanonicalName
    val runtimeClassName = dataClassName.substring(0,dataClassName.length-4).replace(".data.", ".")
    return this.getClass.getClassLoader.loadClass(runtimeClassName).asInstanceOf[Class[_ <: Content]]
  }
  
  override def serialize = {
	  
  }
	
  override def deserialize = {
	  
  }
  */
}