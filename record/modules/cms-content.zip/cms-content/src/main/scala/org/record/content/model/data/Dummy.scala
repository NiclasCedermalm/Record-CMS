package org.record.content.model.data

class Dummy {

  var param1 : String = _
}