package org.record.content.model.data
import java.util.ArrayList

class RuntimeWiredContentData extends ContentData {
  var content: ContentData = _
  var children : java.util.List[ContentData] = new ArrayList[ContentData]
}