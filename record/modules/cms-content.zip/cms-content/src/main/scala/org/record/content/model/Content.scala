package org.record.content.model

import scala.collection.JavaConverters._
import scala.collection.JavaConversions._
import scala.collection.mutable.ListBuffer
import org.record.content.NodeItem
import org.record.content.behaviour.VersionedItem
import javax.persistence.Id
import java.util.ArrayList
import org.record.content.model.data.ContentData
import org.record.content.util.DynamicTraitFactory

/**
 * Runtime Content. All data must be immutable.
 */

object Content {
  def retrieveRuntimeContent[T <: Content](contentData : ContentData) : T = {
    println("Getting runtime content for id: " + contentData.id)
    val traitClassNames = contentData.behaviours.asScala.toList.map(behaviour => behaviour.traitClassName)

    return DynamicTraitFactory.newInstance(retrieveRuntimeContentClass(contentData), Array(contentData), traitClassNames).asInstanceOf[T]
  }
  
  def retrieveRuntimeContentClass(contentData : ContentData) : Class[_ <: Content] = {
    val dataClassName = contentData.getClass.getCanonicalName
    val runtimeClassName = dataClassName.substring(0,dataClassName.length-4).replace(".data.", ".")
    return this.getClass.getClassLoader.loadClass(runtimeClassName).asInstanceOf[Class[_ <: Content]]
  }
}

abstract class Content(val contentData : ContentData) extends VersionedItem {
  
  val id : String = contentData.id
  val parent : HierarchicalContent = getParent
   
  
  //val taxonomies: List[Taxonomy] = _
  
   protected def getParent: HierarchicalContent = {
    if ( contentData.parent == null) return null
    return Content.retrieveRuntimeContent[HierarchicalContent](contentData.parent)
  }
 
}
