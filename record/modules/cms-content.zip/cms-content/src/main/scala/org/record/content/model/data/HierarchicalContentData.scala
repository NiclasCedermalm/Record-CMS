package org.record.content.model.data
import java.util.ArrayList

class HierarchicalContentData extends ContentData {

  var name : String = _
  var children : java.util.List[ContentData] = new ArrayList[ContentData]
}