package org.record.content.model.data
import java.util.HashMap

class CompositeContentData extends ContentData {
  
	var children : HashMap[String,ContentData] = new HashMap[String,ContentData]
}