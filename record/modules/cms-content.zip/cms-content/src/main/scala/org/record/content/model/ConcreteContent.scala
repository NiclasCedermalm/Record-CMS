package org.record.content.model

import scala.collection.mutable.ListBuffer
import org.record.content.model.data.ConcreteContentData

abstract class ConcreteContent(override val contentData : ConcreteContentData) extends Content(contentData) {

 
  // TODO: Always associate with a behaviour when adding content here??
  
}