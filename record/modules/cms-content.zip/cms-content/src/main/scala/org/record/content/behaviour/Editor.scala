package org.record.content.behaviour

trait Editor extends Behaviour {
	
}