package org.record.content.behaviour

trait Behaviour {
}