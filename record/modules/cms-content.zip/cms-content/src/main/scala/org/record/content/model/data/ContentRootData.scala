package org.record.content.model.data

class ContentRootData extends HierarchicalContentData {
	
}