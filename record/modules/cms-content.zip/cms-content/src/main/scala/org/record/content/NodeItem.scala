package org.record.content
import com.orientechnologies.orient.core.record.impl.ODocument

import javax.persistence.{Version, Id}

trait NodeItem {

	//var id : String = null;
	def id : String = {
	  if ( node != null ) {
		  return node.getIdentity().toString()
	  }
	  return null
	}
	var node : ODocument = null;

	def serialize
	
	def deserialize
}