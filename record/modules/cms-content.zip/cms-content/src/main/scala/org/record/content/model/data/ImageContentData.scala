package org.record.content.model.data

class ImageContentData extends ConcreteContentData {
  var imageName: String = _
  var image: Array[Byte] = _
}