package org.record.content.model.data
import java.util.HashMap
import javax.persistence.Id
import java.util.ArrayList


/*
 * Behaviour Data
 * 
 * Inherit structure or??? Editors for those??
 */


class BehaviourData {
  
	@Id
    var id : String = _
    
	var traitClassName : String = _
	var parameters : HashMap[String,Any] = new HashMap[String,Any]
	
	var dummy : java.util.List[Dummy] = new java.util.ArrayList[Dummy]
	
	// TODO: Behaviour can also have behaviour, for example if you want to have an editor for an behaviour
	// TODO: Is Behaviour content???
}