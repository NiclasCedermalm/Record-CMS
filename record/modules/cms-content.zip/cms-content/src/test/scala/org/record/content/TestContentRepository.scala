package org.record.content
import com.orientechnologies.orient.core.db.`object`.ODatabaseObjectTx
import org.record.content.model.TextContent
import com.orientechnologies.orient.core.sql.query.OSQLSynchQuery
import scala.collection.JavaConverters._
import scala.collection.JavaConversions._
import org.record.content.model._
import org.record.content.behaviour._
import org.record.content.model.data._

object TestContentRepository extends App {

  // TODO: Create default constructors for all models!!!

  var db = new ODatabaseObjectTx("local:/Users/nic/Develop/orientdb/cms-test")
  db.open("admin", "admin")
  
  /*
  db.delete()
  db.create
  db.open("admin","admin")
  */
  
  // Cascading delete??
  
  var contentRepo = new ContentRepository(db)
 
  
  var root = contentRepo.getContentRoot("stage")
  if ( root == null ) {
    var rootData = new ContentRootData
    rootData.name = "stage"
    contentRepo.save(rootData)
    root = Content.retrieveRuntimeContent[ContentRoot](rootData)
    println("Created root node with id:" + root.id)
  }
  
  println("Root children:")
  for ( content <- root.children ) {
    println("Content id: " + content.id + ", " + content.contentData)
  }
  
  var page1 = new PageData
  page1.filename = "filename.html"
  page1.path = "/path1"
  db.save(page1)

  var text1 = new TextContentData
  text1.text = "Tjabba"
  text1.parent = root.contentData.parent
  text1.test = "TEST"
  db.save(text1)
  
  var article1 = new CompositeContentData
  article1.children.put("text1", text1)
  db.save(article1)
  
  var template1 = new BehaviourData
  template1.traitClassName = classOf[PlayTemplate].getCanonicalName()
  db.save(template1)
  
  var compPres1 = new RuntimeWiredContentData
  compPres1.content = article1 // This does not work!!!!
  compPres1.behaviours += template1
  db.save(compPres1)
  
  page1.children.add(compPres1)
  db.save(page1)
  
  root.contentData.children += page1
  db.save(root.contentData)  
  
  //
  //var testPage = new PageData
  //testPage.title = "Test Page"
  //testPage.parent = root.contentData
  //root.contentData.children += testPage
  
  // TODO: HOW TO FIX behaviour specific data???
  //testPage.templateFunctionName = "views.html.pagetemplate1"
    /*
  var article = new CompositeContent
  article.children.put("title", new TextContent("Article Title"))
  article.children.put("body", new TextContent("<p>Some paragraphs comes here...</p><p>Plus some more comes here</p>"))


  var articlePresentation = new RuntimeWiredContent with PlayTemplate
  articlePresentation.content = article
  articlePresentation.target = article // TODO: Make this in a cleaner way using implicits
  articlePresentation.templateFunctionName = "views.html.articletemplate1"

  // Regions? Just some different types of containers I suppose??
  testPage.children.append(articlePresentation)
  */
  println("Saving content...")
  //contentRepo.save(testPage)
  //contentRepo.save(root.contentData)
  println("Save done.")
  
  db.close

}