package org.record.content
import org.specs2.Specification

/*
class TestContent extends Specification {
	"Content behaviour" should {
	  "should be 
	}
}
*/