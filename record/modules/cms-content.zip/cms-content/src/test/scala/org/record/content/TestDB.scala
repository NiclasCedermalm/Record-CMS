package org.record.content
import com.orientechnologies.orient.core.Orient
import com.orientechnologies.orient.client.remote.OEngineRemote
import com.orientechnologies.orient.core.db.graph.OGraphDatabase
import com.orientechnologies.orient.core.sql.query.OSQLSynchQuery
import scala.collection.JavaConverters._
import scala.collection.JavaConversions._

object TestDB {

  def main(args: Array[String]): Unit = {
    
    implicit def dbWrapper(db: OGraphDatabase) = new {
	 def queryBySql[T](sql: String, params: AnyRef*): List[T] = {
        val params4java = params.toArray
        val results: java.util.List[T] = db.query(new OSQLSynchQuery[T](sql), params4java: _*)
        results.asScala.toList
     }
   }
    
    //Orient.instance().registerEngine(new OEngineRemote());
    //var db = new OGraphDatabase("remote:/cms-db");
    var db = new OGraphDatabase("local:/Users/nic/Develop/orientdb/cms-test");
    db.open("admin", "admin");
    
    //var baseClass = db.createVertexType("Base")
    //var subClass = db.createVertexType("Sub", "Base")
    
    var node1 = db.createVertex("Sub")
    node1.field("param1", "hello")
    db.save(node1)
    
    var node2 = db.createVertex("Base")
    node1.field("param1", "hello")
    db.save(node2)
    
    var list = db.queryBySql("select from base")
    println("Base List Size: "  + list.size) 
    
    list = db.queryBySql("select from sub")
    println("Sub List Size: "  + list.size) 
    
    db.close();
    
  }

}